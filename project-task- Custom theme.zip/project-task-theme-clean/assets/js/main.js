document.addEventListener('DOMContentLoaded',function(){
  var btn=document.querySelector('.menu-toggle');
  var menu=document.querySelector('.main-menu');
  if(btn&&menu){
    btn.addEventListener('click',function(){
      var expanded=this.getAttribute('aria-expanded')==='true'||false;
      this.setAttribute('aria-expanded',!expanded);
      menu.classList.toggle('show');
    });
  }
});
