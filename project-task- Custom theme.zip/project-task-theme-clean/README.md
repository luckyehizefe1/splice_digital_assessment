Project Task Theme
==================
Minimal custom theme implementing:
- Custom page templates (Home, Blog)
- Projects custom post type with meta fields
- Archive & single templates
- Menu with nested support
- REST endpoint: /wp-json/projecttheme/v1/projects
- Responsive layout

Install: Appearance → Themes → Add New → Upload Theme → Activate.
