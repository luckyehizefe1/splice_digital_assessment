<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
    register_nav_menus(['primary' => __('Primary Menu', 'project-task-theme')]);
});

add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('project-theme-style', get_stylesheet_uri(), [], '1.0.0');
    wp_enqueue_style('project-theme-main', get_template_directory_uri() . '/assets/css/main.css', [], '1.0.0');
    wp_enqueue_script('project-theme-main', get_template_directory_uri() . '/assets/js/main.js', ['jquery'], '1.0.0', true);
});

add_action('init', function () {
    register_post_type('projects', [
        'labels' => [
            'name' => __('Projects','project-task-theme'),
            'singular_name' => __('Project','project-task-theme'),
            'add_new_item' => __('Add New Project','project-task-theme'),
            'edit_item' => __('Edit Project','project-task-theme'),
            'view_item' => __('View Project','project-task-theme'),
            'all_items' => __('All Projects','project-task-theme'),
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'menu_icon' => 'dashicons-portfolio',
        'rewrite' => ['slug' => 'projects'],
        'supports' => ['title','editor','thumbnail','excerpt'],
    ]);
});

add_action('add_meta_boxes', function () {
    add_meta_box('project_details', __('Project Details','project-task-theme'), function($post){
        wp_nonce_field('project_details_nonce','project_details_nonce_field');
        $fields = [
            'project_name' => get_post_meta($post->ID, 'project_name', true),
            'project_description' => get_post_meta($post->ID, 'project_description', true),
            'project_start_date' => get_post_meta($post->ID, 'project_start_date', true),
            'project_end_date' => get_post_meta($post->ID, 'project_end_date', true),
            'project_url' => get_post_meta($post->ID, 'project_url', true),
        ]; ?>
        <p><label><?php esc_html_e('Project Name','project-task-theme'); ?></label><br>
        <input type="text" name="project_name" value="<?php echo esc_attr($fields['project_name']); ?>" style="width:100%"></p>

        <p><label><?php esc_html_e('Project Description','project-task-theme'); ?></label><br>
        <textarea name="project_description" rows="4" style="width:100%"><?php echo esc_textarea($fields['project_description']); ?></textarea></p>

        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <p><label><?php esc_html_e('Start Date','project-task-theme'); ?></label><br>
          <input type="date" name="project_start_date" value="<?php echo esc_attr($fields['project_start_date']); ?>"></p>
          <p><label><?php esc_html_e('End Date','project-task-theme'); ?></label><br>
          <input type="date" name="project_end_date" value="<?php echo esc_attr($fields['project_end_date']); ?>"></p>
        </div>

        <p><label><?php esc_html_e('Project URL','project-task-theme'); ?></label><br>
        <input type="url" name="project_url" value="<?php echo esc_attr($fields['project_url']); ?>" style="width:100%"></p>
    <?php }, 'projects', 'normal', 'high');
});

add_action('save_post', function ($post_id) {
    if (!isset($_POST['project_details_nonce_field']) || !wp_verify_nonce($_POST['project_details_nonce_field'], 'project_details_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (get_post_type($post_id) !== 'projects') return;

    $map = [
        'project_name' => 'sanitize_text_field',
        'project_description' => 'wp_kses_post',
        'project_start_date' => 'sanitize_text_field',
        'project_end_date' => 'sanitize_text_field',
        'project_url' => 'esc_url_raw',
    ];
    foreach ($map as $key => $san) {
        if (isset($_POST[$key])) {
            update_post_meta($post_id, $key, call_user_func($san, $_POST[$key]));
        }
    }
}, 10, 1);

add_action('rest_api_init', function () {
    register_rest_route('projecttheme/v1', '/projects', [
        'methods' => 'GET',
        'callback' => function () {
            $posts = get_posts(['post_type' => 'projects', 'numberposts' => -1, 'post_status' => 'publish']);
            $out = [];
            foreach ($posts as $p) {
                $out[] = [
                    'title' => get_the_title($p->ID),
                    'url' => get_post_meta($p->ID,'project_url', true),
                    'start_date' => get_post_meta($p->ID,'project_start_date', true),
                    'end_date' => get_post_meta($p->ID,'project_end_date', true),
                    'permalink' => get_permalink($p->ID),
                ];
            }
            return rest_ensure_response($out);
        },
        'permission_callback' => '__return_true'
    ]);
});
