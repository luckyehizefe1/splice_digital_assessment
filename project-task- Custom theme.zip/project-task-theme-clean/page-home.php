<?php /* Template Name: Home Page */ get_header(); ?>
<section class="hero">
  <div class="container">
    <h2><?php echo esc_html( get_bloginfo('name') ); ?></h2>
    <p><?php echo esc_html( get_bloginfo('description') ); ?></p>
    <a class="btn" href="<?php echo esc_url( get_post_type_archive_link('projects') ); ?>"><?php esc_html_e('View Projects', 'project-task-theme'); ?></a>
  </div>
</section>
<section class="container">
  <h3><?php esc_html_e('Latest Projects', 'project-task-theme'); ?></h3>
  <div class="grid">
  <?php $q = new WP_Query(['post_type'=>'projects','posts_per_page'=>3]);
    if ($q->have_posts()): while ($q->have_posts()): $q->the_post(); ?>
      <article class="card">
        <?php if (has_post_thumbnail()) the_post_thumbnail('medium'); ?>
        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
        <p><?php echo esc_html( wp_trim_words( get_the_content(), 18 ) ); ?></p>
      </article>
  <?php endwhile; wp_reset_postdata(); else: ?>
    <p><?php esc_html_e('No projects yet.', 'project-task-theme'); ?></p>
  <?php endif; ?>
  </div>
</section>
<?php get_footer(); ?>
