<?php get_header(); ?>
<div class="container">
  <h2><?php esc_html_e('Latest', 'project-task-theme'); ?></h2>
  <div class="grid">
  <?php if (have_posts()): while (have_posts()): the_post(); ?>
    <article <?php post_class('card'); ?>>
      <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
      <p><?php echo esc_html( wp_trim_words( get_the_content(), 24 ) ); ?></p>
    </article>
  <?php endwhile; else: ?>
    <p><?php esc_html_e('No posts found.', 'project-task-theme'); ?></p>
  <?php endif; ?>
  </div>
</div>
<?php get_footer(); ?>
