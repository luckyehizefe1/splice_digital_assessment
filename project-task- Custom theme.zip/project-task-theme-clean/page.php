<?php get_header(); ?>
<div class="container">
<?php if (have_posts()): while (have_posts()): the_post(); ?>
  <article <?php post_class('card'); ?>>
    <h1><?php the_title(); ?></h1>
    <div class="entry"><?php the_content(); ?></div>
    <?php comments_template(); ?>
  </article>
<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
