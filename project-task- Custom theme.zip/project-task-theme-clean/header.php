<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header class="site-header">
  <div class="container brand">
    <div>
      <p class="title"><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></p>
      <p class="tag"><?php bloginfo('description'); ?></p>
    </div>
    <div class="main-nav" style="margin-left:auto">
      <button class="menu-toggle" aria-expanded="false" aria-controls="primary-menu">Menu</button>
      <?php
        wp_nav_menu([
          'theme_location' => 'primary',
          'container' => false,
          'menu_id' => 'primary-menu',
          'menu_class' => 'main-menu',
          'depth' => 2,
          'fallback_cb' => function(){
            echo '<ul class="main-menu"><li><a href="' . esc_url(admin_url('nav-menus.php')) . '">Set up menu</a></li></ul>';
          }
        ]);
      ?>
    </div>
  </div>
</header>
<main class="site-main">
