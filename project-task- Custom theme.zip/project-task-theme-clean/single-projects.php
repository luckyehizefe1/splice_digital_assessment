<?php get_header(); ?>
<div class="container">
<?php if (have_posts()): while (have_posts()): the_post(); ?>
  <article <?php post_class('card'); ?>>
    <h2><?php the_title(); ?></h2>
    <?php if (has_post_thumbnail()) the_post_thumbnail('large'); ?>
    <div class="project-meta">
      <p><strong><?php esc_html_e('Project Name','project-task-theme'); ?>:</strong> <?php echo esc_html( get_post_meta(get_the_ID(),'project_name',true) ); ?></p>
      <p><strong><?php esc_html_e('Start Date','project-task-theme'); ?>:</strong> <?php echo esc_html( get_post_meta(get_the_ID(),'project_start_date',true) ); ?></p>
      <p><strong><?php esc_html_e('End Date','project-task-theme'); ?>:</strong> <?php echo esc_html( get_post_meta(get_the_ID(),'project_end_date',true) ); ?></p>
      <p><strong><?php esc_html_e('URL','project-task-theme'); ?>:</strong>
        <?php $url = get_post_meta(get_the_ID(),'project_url',true);
          if ($url) echo '<a href="'. esc_url($url) .'" target="_blank" rel="noopener">'. esc_html($url) .'</a>'; ?>
      </p>
    </div>
    <h3><?php esc_html_e('Project Description','project-task-theme'); ?></h3>
    <div class="content">
      <?php echo wp_kses_post( wpautop( get_post_meta(get_the_ID(),'project_description',true) ) ); ?>
    </div>
    <div class="entry"><?php the_content(); ?></div>
  </article>
<?php endwhile; endif; ?>
</div>
<?php get_footer(); ?>
