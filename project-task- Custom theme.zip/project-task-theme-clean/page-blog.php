<?php /* Template Name: Blog Page */ get_header(); ?>
<div class="container">
  <h2><?php esc_html_e('Blog', 'project-task-theme'); ?></h2>
  <?php $blog = new WP_Query(['post_type'=>'post','posts_per_page'=>10]);
    if ($blog->have_posts()): echo '<div class="grid">';
      while ($blog->have_posts()): $blog->the_post(); ?>
        <article class="card">
          <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
          <p><?php echo esc_html( wp_trim_words( get_the_content(), 22 ) ); ?></p>
        </article>
  <?php endwhile; echo '</div>'; wp_reset_postdata(); else: ?>
    <p><?php esc_html_e('No posts found.', 'project-task-theme'); ?></p>
  <?php endif; ?>
</div>
<?php get_footer(); ?>
