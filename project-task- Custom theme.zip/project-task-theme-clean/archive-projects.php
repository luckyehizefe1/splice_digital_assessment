<?php get_header(); ?>
<div class="container">
  <h2><?php esc_html_e('Projects', 'project-task-theme'); ?></h2>
  <form method="get" class="filter-form">
    <label><?php esc_html_e('From', 'project-task-theme'); ?>
      <input type="date" name="start_date" value="<?php echo isset($_GET['start_date']) ? esc_attr($_GET['start_date']) : ''; ?>">
    </label>
    <label><?php esc_html_e('To', 'project-task-theme'); ?>
      <input type="date" name="end_date" value="<?php echo isset($_GET['end_date']) ? esc_attr($_GET['end_date']) : ''; ?>">
    </label>
    <button class="btn" type="submit"><?php esc_html_e('Filter', 'project-task-theme'); ?></button>
    <a class="btn" href="<?php echo esc_url( get_post_type_archive_link('projects') ); ?>"><?php esc_html_e('Reset', 'project-task-theme'); ?></a>
  </form>
  <div class="grid">
  <?php
    $meta_query = ['relation'=>'AND'];
    if (!empty($_GET['start_date'])) $meta_query[] = ['key'=>'project_start_date','value'=>sanitize_text_field($_GET['start_date']),'compare'=>'>=','type'=>'DATE'];
    if (!empty($_GET['end_date'])) $meta_query[] = ['key'=>'project_end_date','value'=>sanitize_text_field($_GET['end_date']),'compare'=>'<=','type'=>'DATE'];
    $args = ['post_type'=>'projects','posts_per_page'=>9];
    if (count($meta_query) > 1) $args['meta_query'] = $meta_query;
    $q = new WP_Query($args);
    if ($q->have_posts()):
      while ($q->have_posts()): $q->the_post(); ?>
        <article class="card">
          <?php if (has_post_thumbnail()) the_post_thumbnail('medium'); ?>
          <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
          <p><strong><?php esc_html_e('Start','project-task-theme'); ?>:</strong> <?php echo esc_html( get_post_meta(get_the_ID(),'project_start_date',true) ); ?></p>
          <p><strong><?php esc_html_e('End','project-task-theme'); ?>:</strong> <?php echo esc_html( get_post_meta(get_the_ID(),'project_end_date',true) ); ?></p>
        </article>
      <?php endwhile; wp_reset_postdata();
    else: ?>
      <p><?php esc_html_e('No projects found.', 'project-task-theme'); ?></p>
    <?php endif; ?>
  </div>
</div>
<?php get_footer(); ?>
